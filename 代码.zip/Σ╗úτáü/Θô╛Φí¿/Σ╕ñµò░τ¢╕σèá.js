var addTwoNumbers = function(l1, l2) {
    let c1 = l1  // l1节点
    let c2 = l2  // l2节点
    let c3       // l3节点
    let l3 // 输出的链表l3
    let carry = 0; // 进位
    // c1 c2的节点存在 （c1 c2都结束了 到终点了 但是还存在进位还是要继续进一）进位还存在的
    while (c1 || c2 || carry) {
        // 考虑到短的链表节点可能为 null，以 0 代替
        let v1 = c1 ? v1.val : 0
        let v2 = c2 ? v2.val : 0
        let sum = carry + v1 + v2
        // 取进位 0或1
        carry = Math.floor(sum/10)
        // 输出链表的节点
        if(c3) {
            // sum % 10 取个位
            c3.next = new ListNode(sum % 10)
            c3 = c3.next
        }else {
            l3 = new ListNode( sum % 10 )
            c3 = l3
        }
        // 后移
        if (c1) {
            c1 = c1.next
        }
        if (c2) {
            c2 = c2.next
        }
    }

};